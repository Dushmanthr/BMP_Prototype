import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Heart,
  Plus,
  Gift,
  HardDrive,
  ShoppingBag,
  Sparkles,
  Menu,
  X,
  User as UserIcon,
  LogOut,
  ChevronDown,
  BookOpen,
  Music,
} from 'lucide-react';
import { AppView } from '../../types';

export const Header: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    user,
    logout,
    activeOccasion,
    setActiveRolePreview,
  } = useApp();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);

  // Determine current mode
  const isContributorView =
    currentView === 'contributor-consent' ||
    currentView === 'contributor-upload' ||
    currentView === 'contributor-my-memories';

  const isCelebrationPersonView = currentView === 'celebration-page';

  const handleNav = (view: AppView) => {
    setCurrentView(view);
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-gray-100 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Brand Logo */}
        <button
          onClick={() => handleNav(user ? 'creator-dashboard' : 'landing')}
          id="header-logo-btn"
          className="flex items-center gap-2.5 text-left group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-2xl bg-[#FF6B6B]/10 flex items-center justify-center text-[#FF6B6B] group-hover:bg-[#FF6B6B] group-hover:text-white transition-all duration-200">
            <Heart className="w-5 h-5 fill-current" />
          </div>
          <div>
            <span className="font-extrabold text-lg sm:text-xl text-[#243B53] tracking-tight block leading-tight">
              Moments <span className="text-[#FF6B6B]">&</span> Memories
            </span>
            <span className="text-[11px] text-gray-500 font-medium block">
              Digital Celebration Platform
            </span>
          </div>
        </button>

        {/* View-Specific Navigation - Desktop */}
        {!isContributorView && !isCelebrationPersonView && (
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {user ? (
              <>
                <button
                  onClick={() => handleNav('creator-dashboard')}
                  id="nav-my-occasions-btn"
                  className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    currentView === 'creator-dashboard'
                      ? 'bg-[#243B53] text-white'
                      : 'text-[#243B53] hover:bg-gray-100'
                  }`}
                >
                  My Occasions
                </button>
                <button
                  onClick={() => handleNav('occasion-space')}
                  id="nav-memory-space-btn"
                  className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    currentView === 'occasion-space' || currentView === 'creator-review'
                      ? 'bg-[#243B53] text-white'
                      : 'text-[#243B53] hover:bg-gray-100'
                  }`}
                >
                  Memories Space
                </button>
                <button
                  onClick={() => handleNav('digital-keepsake')}
                  id="nav-keepsakes-btn"
                  className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    currentView === 'digital-keepsake' || currentView === 'physical-keepsake'
                      ? 'bg-[#243B53] text-white'
                      : 'text-[#243B53] hover:bg-gray-100'
                  }`}
                >
                  Keepsakes
                </button>
                <button
                  onClick={() => handleNav('digital-store')}
                  id="nav-digital-store-btn"
                  className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    currentView === 'digital-store'
                      ? 'bg-[#243B53] text-white'
                      : 'text-[#243B53] hover:bg-gray-100'
                  }`}
                >
                  Digital Store
                </button>
                <button
                  onClick={() => handleNav('gift-finder')}
                  id="nav-gift-finder-btn"
                  className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    currentView === 'gift-finder'
                      ? 'bg-[#243B53] text-white'
                      : 'text-[#243B53] hover:bg-gray-100'
                  }`}
                >
                  <Gift className="w-4 h-4 text-[#FF6B6B]" />
                  Gift Finder
                </button>
                <button
                  onClick={() => handleNav('ai-birthday-song')}
                  id="nav-ai-song-btn"
                  className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    currentView === 'ai-birthday-song'
                      ? 'bg-[#243B53] text-white'
                      : 'text-[#243B53] hover:bg-gray-100'
                  }`}
                >
                  <Music className="w-4 h-4 text-[#FF6B6B]" />
                  AI Song
                </button>
                <button
                  onClick={() => handleNav('storage')}
                  id="nav-storage-btn"
                  className={`px-3 py-2 rounded-xl text-sm font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    currentView === 'storage'
                      ? 'bg-[#243B53] text-white'
                      : 'text-[#243B53] hover:bg-gray-100'
                  }`}
                >
                  <HardDrive className="w-4 h-4" />
                  Storage
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => handleNav('landing')}
                  className="px-3.5 py-2 rounded-xl text-sm font-medium text-[#243B53] hover:bg-gray-100 cursor-pointer"
                >
                  How It Works
                </button>
                <button
                  onClick={() => handleNav('digital-keepsake')}
                  className="px-3.5 py-2 rounded-xl text-sm font-medium text-[#243B53] hover:bg-gray-100 cursor-pointer"
                >
                  Keepsakes
                </button>
                <button
                  onClick={() => handleNav('gift-finder')}
                  className="px-3.5 py-2 rounded-xl text-sm font-medium text-[#243B53] hover:bg-gray-100 cursor-pointer flex items-center gap-1"
                >
                  <Gift className="w-4 h-4 text-[#FF6B6B]" />
                  Find a Gift
                </button>
              </>
            )}
          </nav>
        )}

        {/* Contributor Header Mode */}
        {isContributorView && (
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline-block px-3 py-1 bg-amber-50 text-amber-900 border border-amber-200 text-xs font-semibold rounded-full">
              Contributor Mode (No Login Required)
            </span>
            <button
              onClick={() => handleNav('contributor-my-memories')}
              id="contributor-my-memories-btn"
              className="text-xs sm:text-sm font-semibold text-[#243B53] hover:text-[#FF6B6B] transition-colors cursor-pointer underline underline-offset-4"
            >
              My Contributions
            </button>
          </div>
        )}

        {/* Celebration Person Header Mode */}
        {isCelebrationPersonView && (
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-[#FF6B6B]/10 text-[#FF6B6B] text-xs font-bold rounded-full flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Celebration Experience
            </span>
            <button
              onClick={() => handleNav('creator-dashboard')}
              className="text-xs text-gray-500 hover:text-[#243B53] cursor-pointer"
            >
              Exit to Dashboard
            </button>
          </div>
        )}

        {/* Actions & Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          {user ? (
            <>
              <button
                onClick={() => handleNav('create-occasion')}
                id="header-create-occasion-cta"
                className="hidden sm:inline-flex items-center gap-2 px-4 py-2.5 bg-[#FF6B6B] hover:bg-[#fa5a5a] text-white font-semibold text-sm rounded-xl shadow-sm transition-all transform active:scale-95 cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                Create Occasion
              </button>

              {/* User Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                  id="user-profile-menu-btn"
                  className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-gray-100 transition-colors cursor-pointer"
                >
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-9 h-9 rounded-xl object-cover border border-gray-200"
                  />
                  <ChevronDown className="w-4 h-4 text-gray-500 hidden sm:block" />
                </button>

                {isProfileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-50 animate-in fade-in zoom-in-95">
                    <div className="px-4 py-2.5 border-b border-gray-100">
                      <p className="text-xs text-gray-500">Signed in as</p>
                      <p className="text-sm font-bold text-[#243B53] truncate">
                        {user.name}
                      </p>
                      <p className="text-xs text-gray-500 truncate">{user.email}</p>
                    </div>

                    <button
                      onClick={() => {
                        handleNav('creator-dashboard');
                        setIsProfileDropdownOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-[#243B53] hover:bg-gray-50 font-medium flex items-center gap-2"
                    >
                      <UserIcon className="w-4 h-4 text-gray-400" />
                      My Celebrations
                    </button>
                    <button
                      onClick={() => {
                        handleNav('storage');
                        setIsProfileDropdownOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-[#243B53] hover:bg-gray-50 font-medium flex items-center gap-2"
                    >
                      <HardDrive className="w-4 h-4 text-gray-400" />
                      Storage & Plan
                    </button>
                    <button
                      onClick={() => {
                        handleNav('digital-store');
                        setIsProfileDropdownOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-[#243B53] hover:bg-gray-50 font-medium flex items-center gap-2"
                    >
                      <ShoppingBag className="w-4 h-4 text-gray-400" />
                      Digital Products
                    </button>

                    <div className="border-t border-gray-100 my-1"></div>

                    <button
                      onClick={() => {
                        logout();
                        setIsProfileDropdownOpen(false);
                      }}
                      id="header-logout-btn"
                      className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 font-medium flex items-center gap-2 cursor-pointer"
                    >
                      <LogOut className="w-4 h-4 text-red-500" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleNav('auth')}
                id="header-signin-btn"
                className="px-4 py-2 text-sm font-semibold text-[#243B53] hover:text-[#FF6B6B] transition-colors cursor-pointer"
              >
                Sign In
              </button>
              <button
                onClick={() => handleNav('create-occasion')}
                id="header-create-first-btn"
                className="px-4 py-2.5 bg-[#FF6B6B] hover:bg-[#fa5a5a] text-white font-semibold text-sm rounded-xl shadow-sm transition-all cursor-pointer"
              >
                Create an Occasion
              </button>
            </div>
          )}

          {/* Mobile Menu Trigger */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 rounded-xl text-[#243B53] hover:bg-gray-100 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-gray-200 px-4 pt-2 pb-6 space-y-2 shadow-xl">
          <button
            onClick={() => handleNav('creator-dashboard')}
            className="w-full text-left px-3 py-2.5 rounded-xl font-semibold text-sm text-[#243B53] hover:bg-gray-50 flex items-center gap-2"
          >
            <Heart className="w-4 h-4 text-[#FF6B6B]" />
            My Occasions
          </button>
          <button
            onClick={() => handleNav('create-occasion')}
            className="w-full text-left px-3 py-2.5 rounded-xl font-semibold text-sm bg-[#FF6B6B] text-white flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            + Create Occasion
          </button>
          <button
            onClick={() => handleNav('occasion-space')}
            className="w-full text-left px-3 py-2.5 rounded-xl font-semibold text-sm text-[#243B53] hover:bg-gray-50 flex items-center gap-2"
          >
            <BookOpen className="w-4 h-4 text-gray-500" />
            Memories Space
          </button>
          <button
            onClick={() => handleNav('celebration-page')}
            className="w-full text-left px-3 py-2.5 rounded-xl font-semibold text-sm text-[#243B53] hover:bg-gray-50 flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-[#FF6B6B]" />
            Celebration Person View
          </button>
          <button
            onClick={() => handleNav('gift-finder')}
            className="w-full text-left px-3 py-2.5 rounded-xl font-semibold text-sm text-[#243B53] hover:bg-gray-50 flex items-center gap-2"
          >
            <Gift className="w-4 h-4 text-[#FF6B6B]" />
            Gift Finder
          </button>
          <button
            onClick={() => handleNav('ai-birthday-song')}
            className="w-full text-left px-3 py-2.5 rounded-xl font-semibold text-sm text-[#243B53] hover:bg-gray-50 flex items-center gap-2"
          >
            <Music className="w-4 h-4 text-[#FF6B6B]" />
            AI Birthday Song
          </button>
          <button
            onClick={() => handleNav('digital-keepsake')}
            className="w-full text-left px-3 py-2.5 rounded-xl font-semibold text-sm text-[#243B53] hover:bg-gray-50 flex items-center gap-2"
          >
            <BookOpen className="w-4 h-4 text-gray-500" />
            Digital & Physical Keepsakes
          </button>
          <button
            onClick={() => handleNav('digital-store')}
            className="w-full text-left px-3 py-2.5 rounded-xl font-semibold text-sm text-[#243B53] hover:bg-gray-50 flex items-center gap-2"
          >
            <ShoppingBag className="w-4 h-4 text-gray-500" />
            Digital Store
          </button>
          <button
            onClick={() => handleNav('storage')}
            className="w-full text-left px-3 py-2.5 rounded-xl font-semibold text-sm text-[#243B53] hover:bg-gray-50 flex items-center gap-2"
          >
            <HardDrive className="w-4 h-4 text-gray-500" />
            Storage Upgrade
          </button>
        </div>
      )}
    </header>
  );
};
